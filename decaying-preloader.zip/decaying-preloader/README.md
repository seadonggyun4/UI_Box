# Decaying Preloader

A Pen created on CodePen.io. Original URL: [https://codepen.io/jkantner/pen/eYjMYPo](https://codepen.io/jkantner/pen/eYjMYPo).

This spinner is running out of gas.