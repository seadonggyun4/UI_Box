# Cute skeuomorphic checkboxes 

A Pen created on CodePen.io. Original URL: [https://codepen.io/LukyVj/pen/bGxwWVv](https://codepen.io/LukyVj/pen/bGxwWVv).

Inspired by https://twitter.com/alvishbaldha/status/1629001485488103424?s=20