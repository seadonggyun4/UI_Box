# Animated Star Rating

A Pen created on CodePen.io. Original URL: [https://codepen.io/jkantner/pen/BarvVNa](https://codepen.io/jkantner/pen/BarvVNa).

A star rating where stars pop out one by one if you choose a higher rating.