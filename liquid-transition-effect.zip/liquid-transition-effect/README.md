# Liquid Transition Effect

A Pen created on CodePen.io. Original URL: [https://codepen.io/TurkAysenur/pen/YzYqdyb](https://codepen.io/TurkAysenur/pen/YzYqdyb).

https://dribbble.com/shots/11915541-Travel-company