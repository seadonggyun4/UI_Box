# CSS Marquee Logo Wall

A Pen created on CodePen.io. Original URL: [https://codepen.io/hexagoncircle/pen/wvmjomb](https://codepen.io/hexagoncircle/pen/wvmjomb).

Responsive infinite scrolling wall of logos. Only HTML and CSS. Includes horizontal and vertical marquee styles. Learn more in <a href="https://ryanmulligan.dev/blog/css-marquee/">The Infinite Marquee</a>